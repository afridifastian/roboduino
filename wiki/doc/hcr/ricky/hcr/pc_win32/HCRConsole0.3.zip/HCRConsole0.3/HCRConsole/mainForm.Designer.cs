﻿namespace HCRConsole
{
    partial class mainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btn_Connect = new System.Windows.Forms.Button();
            this.comboBox_PortRate = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_ComPort = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_Motor_Right = new System.Windows.Forms.Button();
            this.btn_Motor_Stop = new System.Windows.Forms.Button();
            this.btn_Motor_Left = new System.Windows.Forms.Button();
            this.btn_Motor_Backward = new System.Windows.Forms.Button();
            this.btn_Motor_Forward = new System.Windows.Forms.Button();
            this.rTB_Log = new System.Windows.Forms.RichTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkBox_Debug = new System.Windows.Forms.CheckBox();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.timer_Sensor = new System.Windows.Forms.Timer(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label_IR7 = new System.Windows.Forms.Label();
            this.label_IR6 = new System.Windows.Forms.Label();
            this.label_IR5 = new System.Windows.Forms.Label();
            this.label_IR4 = new System.Windows.Forms.Label();
            this.label_IR3 = new System.Windows.Forms.Label();
            this.label_IR2 = new System.Windows.Forms.Label();
            this.label_IR1 = new System.Windows.Forms.Label();
            this.label_BumperR = new System.Windows.Forms.Label();
            this.label_BumperC = new System.Windows.Forms.Label();
            this.label_BumperL = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.trackBar_MotorL = new System.Windows.Forms.TrackBar();
            this.trackBar_MotorR = new System.Windows.Forms.TrackBar();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.button_Light = new System.Windows.Forms.Button();
            this.timer_Motor = new System.Windows.Forms.Timer(this.components);
            this.button_Wander = new System.Windows.Forms.Button();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_MotorL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_MotorR)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btn_Connect);
            this.groupBox4.Controls.Add(this.comboBox_PortRate);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.comboBox_ComPort);
            this.groupBox4.Font = new System.Drawing.Font("Biondi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(12, 12);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(259, 81);
            this.groupBox4.TabIndex = 11;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Setting";
            // 
            // btn_Connect
            // 
            this.btn_Connect.Location = new System.Drawing.Point(170, 21);
            this.btn_Connect.Name = "btn_Connect";
            this.btn_Connect.Size = new System.Drawing.Size(82, 49);
            this.btn_Connect.TabIndex = 7;
            this.btn_Connect.Text = "Connect";
            this.btn_Connect.UseVisualStyleBackColor = true;
            this.btn_Connect.Click += new System.EventHandler(this.btn_Connect_Click);
            // 
            // comboBox_PortRate
            // 
            this.comboBox_PortRate.FormattingEnabled = true;
            this.comboBox_PortRate.Items.AddRange(new object[] {
            "2400",
            "4800",
            "9600",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.comboBox_PortRate.Location = new System.Drawing.Point(83, 49);
            this.comboBox_PortRate.Name = "comboBox_PortRate";
            this.comboBox_PortRate.Size = new System.Drawing.Size(82, 23);
            this.comboBox_PortRate.TabIndex = 7;
            this.comboBox_PortRate.Text = "9600";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "Baud Rate:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "Com Port:";
            // 
            // comboBox_ComPort
            // 
            this.comboBox_ComPort.FormattingEnabled = true;
            this.comboBox_ComPort.Location = new System.Drawing.Point(83, 23);
            this.comboBox_ComPort.Name = "comboBox_ComPort";
            this.comboBox_ComPort.Size = new System.Drawing.Size(82, 23);
            this.comboBox_ComPort.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_Motor_Right);
            this.groupBox1.Controls.Add(this.btn_Motor_Stop);
            this.groupBox1.Controls.Add(this.btn_Motor_Left);
            this.groupBox1.Controls.Add(this.btn_Motor_Backward);
            this.groupBox1.Controls.Add(this.btn_Motor_Forward);
            this.groupBox1.Font = new System.Drawing.Font("Biondi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(277, 248);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(259, 200);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Robot Control";
            // 
            // btn_Motor_Right
            // 
            this.btn_Motor_Right.Location = new System.Drawing.Point(168, 83);
            this.btn_Motor_Right.Name = "btn_Motor_Right";
            this.btn_Motor_Right.Size = new System.Drawing.Size(75, 42);
            this.btn_Motor_Right.TabIndex = 4;
            this.btn_Motor_Right.Text = "Turn Right";
            this.btn_Motor_Right.UseVisualStyleBackColor = true;
            this.btn_Motor_Right.Click += new System.EventHandler(this.btn_Motor_Right_Click);
            // 
            // btn_Motor_Stop
            // 
            this.btn_Motor_Stop.Location = new System.Drawing.Point(87, 75);
            this.btn_Motor_Stop.Name = "btn_Motor_Stop";
            this.btn_Motor_Stop.Size = new System.Drawing.Size(75, 58);
            this.btn_Motor_Stop.TabIndex = 3;
            this.btn_Motor_Stop.Text = "STOP";
            this.btn_Motor_Stop.UseVisualStyleBackColor = true;
            this.btn_Motor_Stop.Click += new System.EventHandler(this.btn_Motor_Stop_Click);
            // 
            // btn_Motor_Left
            // 
            this.btn_Motor_Left.Location = new System.Drawing.Point(6, 83);
            this.btn_Motor_Left.Name = "btn_Motor_Left";
            this.btn_Motor_Left.Size = new System.Drawing.Size(75, 42);
            this.btn_Motor_Left.TabIndex = 2;
            this.btn_Motor_Left.Text = "Turn Left";
            this.btn_Motor_Left.UseVisualStyleBackColor = true;
            this.btn_Motor_Left.Click += new System.EventHandler(this.btn_Motor_Left_Click);
            // 
            // btn_Motor_Backward
            // 
            this.btn_Motor_Backward.Location = new System.Drawing.Point(81, 143);
            this.btn_Motor_Backward.Name = "btn_Motor_Backward";
            this.btn_Motor_Backward.Size = new System.Drawing.Size(89, 42);
            this.btn_Motor_Backward.TabIndex = 1;
            this.btn_Motor_Backward.Text = "Backward";
            this.btn_Motor_Backward.UseVisualStyleBackColor = true;
            this.btn_Motor_Backward.Click += new System.EventHandler(this.btn_Motor_Backward_Click);
            // 
            // btn_Motor_Forward
            // 
            this.btn_Motor_Forward.Location = new System.Drawing.Point(80, 27);
            this.btn_Motor_Forward.Name = "btn_Motor_Forward";
            this.btn_Motor_Forward.Size = new System.Drawing.Size(89, 42);
            this.btn_Motor_Forward.TabIndex = 0;
            this.btn_Motor_Forward.Text = "Forward";
            this.btn_Motor_Forward.UseVisualStyleBackColor = true;
            this.btn_Motor_Forward.Click += new System.EventHandler(this.btn_Motor_Forward_Click);
            // 
            // rTB_Log
            // 
            this.rTB_Log.BackColor = System.Drawing.Color.Black;
            this.rTB_Log.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rTB_Log.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rTB_Log.ForeColor = System.Drawing.Color.Lime;
            this.rTB_Log.Location = new System.Drawing.Point(6, 20);
            this.rTB_Log.Name = "rTB_Log";
            this.rTB_Log.Size = new System.Drawing.Size(247, 196);
            this.rTB_Log.TabIndex = 13;
            this.rTB_Log.Text = "";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rTB_Log);
            this.groupBox2.Controls.Add(this.checkBox_Debug);
            this.groupBox2.Controls.Add(this.btn_Clear);
            this.groupBox2.Font = new System.Drawing.Font("Biondi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 200);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(259, 253);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Debug";
            // 
            // checkBox_Debug
            // 
            this.checkBox_Debug.AutoSize = true;
            this.checkBox_Debug.Location = new System.Drawing.Point(7, 228);
            this.checkBox_Debug.Name = "checkBox_Debug";
            this.checkBox_Debug.Size = new System.Drawing.Size(67, 19);
            this.checkBox_Debug.TabIndex = 17;
            this.checkBox_Debug.Text = "Debug";
            this.checkBox_Debug.UseVisualStyleBackColor = true;
            // 
            // btn_Clear
            // 
            this.btn_Clear.Location = new System.Drawing.Point(178, 228);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(75, 23);
            this.btn_Clear.TabIndex = 18;
            this.btn_Clear.Text = "Clear";
            this.btn_Clear.UseVisualStyleBackColor = true;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // timer_Sensor
            // 
            this.timer_Sensor.Interval = 80;
            this.timer_Sensor.Tick += new System.EventHandler(this.timer_Sensor_Tick);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox3.Controls.Add(this.label_IR7);
            this.groupBox3.Controls.Add(this.label_IR6);
            this.groupBox3.Controls.Add(this.label_IR5);
            this.groupBox3.Controls.Add(this.label_IR4);
            this.groupBox3.Controls.Add(this.label_IR3);
            this.groupBox3.Controls.Add(this.label_IR2);
            this.groupBox3.Controls.Add(this.label_IR1);
            this.groupBox3.Font = new System.Drawing.Font("Biondi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(277, 99);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(298, 143);
            this.groupBox3.TabIndex = 15;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Infrared Sensor";
            // 
            // label_IR7
            // 
            this.label_IR7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label_IR7.Font = new System.Drawing.Font("Biondi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IR7.Location = new System.Drawing.Point(161, 103);
            this.label_IR7.Name = "label_IR7";
            this.label_IR7.Size = new System.Drawing.Size(55, 32);
            this.label_IR7.TabIndex = 9;
            this.label_IR7.Text = "IR7";
            this.label_IR7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_IR6
            // 
            this.label_IR6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label_IR6.Font = new System.Drawing.Font("Biondi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IR6.Location = new System.Drawing.Point(87, 103);
            this.label_IR6.Name = "label_IR6";
            this.label_IR6.Size = new System.Drawing.Size(55, 32);
            this.label_IR6.TabIndex = 8;
            this.label_IR6.Text = "IR6";
            this.label_IR6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_IR5
            // 
            this.label_IR5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label_IR5.Font = new System.Drawing.Font("Biondi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IR5.Location = new System.Drawing.Point(235, 59);
            this.label_IR5.Name = "label_IR5";
            this.label_IR5.Size = new System.Drawing.Size(55, 32);
            this.label_IR5.TabIndex = 7;
            this.label_IR5.Text = "IR5";
            this.label_IR5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_IR4
            // 
            this.label_IR4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label_IR4.Font = new System.Drawing.Font("Biondi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IR4.Location = new System.Drawing.Point(193, 17);
            this.label_IR4.Name = "label_IR4";
            this.label_IR4.Size = new System.Drawing.Size(55, 32);
            this.label_IR4.TabIndex = 6;
            this.label_IR4.Text = "IR4";
            this.label_IR4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_IR3
            // 
            this.label_IR3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label_IR3.Font = new System.Drawing.Font("Biondi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IR3.Location = new System.Drawing.Point(127, 17);
            this.label_IR3.Name = "label_IR3";
            this.label_IR3.Size = new System.Drawing.Size(55, 32);
            this.label_IR3.TabIndex = 3;
            this.label_IR3.Text = "IR3";
            this.label_IR3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_IR3.Click += new System.EventHandler(this.label_IR3_Click);
            // 
            // label_IR2
            // 
            this.label_IR2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label_IR2.Font = new System.Drawing.Font("Biondi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IR2.Location = new System.Drawing.Point(62, 17);
            this.label_IR2.Name = "label_IR2";
            this.label_IR2.Size = new System.Drawing.Size(55, 32);
            this.label_IR2.TabIndex = 2;
            this.label_IR2.Text = "IR2";
            this.label_IR2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_IR2.Click += new System.EventHandler(this.label_IR2_Click);
            // 
            // label_IR1
            // 
            this.label_IR1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.label_IR1.Font = new System.Drawing.Font("Biondi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_IR1.Location = new System.Drawing.Point(9, 59);
            this.label_IR1.Name = "label_IR1";
            this.label_IR1.Size = new System.Drawing.Size(55, 31);
            this.label_IR1.TabIndex = 0;
            this.label_IR1.Text = "IR1";
            this.label_IR1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label_IR1.Click += new System.EventHandler(this.label_IR1_Click);
            // 
            // label_BumperR
            // 
            this.label_BumperR.BackColor = System.Drawing.Color.Green;
            this.label_BumperR.Location = new System.Drawing.Point(197, 29);
            this.label_BumperR.Name = "label_BumperR";
            this.label_BumperR.Size = new System.Drawing.Size(90, 32);
            this.label_BumperR.TabIndex = 5;
            this.label_BumperR.Text = "Right Bumper";
            this.label_BumperR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_BumperC
            // 
            this.label_BumperC.BackColor = System.Drawing.Color.Green;
            this.label_BumperC.Location = new System.Drawing.Point(101, 29);
            this.label_BumperC.Name = "label_BumperC";
            this.label_BumperC.Size = new System.Drawing.Size(90, 32);
            this.label_BumperC.TabIndex = 4;
            this.label_BumperC.Text = "Center Bumper";
            this.label_BumperC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_BumperL
            // 
            this.label_BumperL.BackColor = System.Drawing.Color.Green;
            this.label_BumperL.Location = new System.Drawing.Point(5, 29);
            this.label_BumperL.Name = "label_BumperL";
            this.label_BumperL.Size = new System.Drawing.Size(90, 32);
            this.label_BumperL.TabIndex = 1;
            this.label_BumperL.Text = "Left Bumper";
            this.label_BumperL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.trackBar_MotorL);
            this.groupBox5.Controls.Add(this.trackBar_MotorR);
            this.groupBox5.Font = new System.Drawing.Font("Biondi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(542, 248);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(148, 200);
            this.groupBox5.TabIndex = 16;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Motor Control";
            // 
            // trackBar_MotorL
            // 
            this.trackBar_MotorL.LargeChange = 10;
            this.trackBar_MotorL.Location = new System.Drawing.Point(28, 23);
            this.trackBar_MotorL.Maximum = 100;
            this.trackBar_MotorL.Minimum = -100;
            this.trackBar_MotorL.Name = "trackBar_MotorL";
            this.trackBar_MotorL.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar_MotorL.Size = new System.Drawing.Size(45, 173);
            this.trackBar_MotorL.SmallChange = 10;
            this.trackBar_MotorL.TabIndex = 2;
            this.trackBar_MotorL.TickFrequency = 10;
            this.trackBar_MotorL.Scroll += new System.EventHandler(this.trackBar_MotorL_Scroll);
            // 
            // trackBar_MotorR
            // 
            this.trackBar_MotorR.LargeChange = 10;
            this.trackBar_MotorR.Location = new System.Drawing.Point(91, 23);
            this.trackBar_MotorR.Maximum = 100;
            this.trackBar_MotorR.Minimum = -100;
            this.trackBar_MotorR.Name = "trackBar_MotorR";
            this.trackBar_MotorR.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar_MotorR.Size = new System.Drawing.Size(45, 173);
            this.trackBar_MotorR.SmallChange = 10;
            this.trackBar_MotorR.TabIndex = 3;
            this.trackBar_MotorR.TickFrequency = 10;
            this.trackBar_MotorR.Scroll += new System.EventHandler(this.trackBar_MotorR_Scroll);
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox6.Controls.Add(this.label_BumperL);
            this.groupBox6.Controls.Add(this.label_BumperC);
            this.groupBox6.Controls.Add(this.label_BumperR);
            this.groupBox6.Font = new System.Drawing.Font("Biondi", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(277, 12);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(298, 81);
            this.groupBox6.TabIndex = 19;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Bumper Sensor";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 456);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(702, 22);
            this.statusStrip1.TabIndex = 20;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(83, 17);
            this.toolStripStatusLabel1.Text = "Version: 0.33";
            // 
            // button_Light
            // 
            this.button_Light.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button_Light.Font = new System.Drawing.Font("Biondi", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Light.Location = new System.Drawing.Point(12, 99);
            this.button_Light.Name = "button_Light";
            this.button_Light.Size = new System.Drawing.Size(259, 52);
            this.button_Light.TabIndex = 21;
            this.button_Light.Text = "Light";
            this.button_Light.UseVisualStyleBackColor = false;
            this.button_Light.Click += new System.EventHandler(this.button_Light_Click);
            // 
            // timer_Motor
            // 
            this.timer_Motor.Interval = 200;
            this.timer_Motor.Tick += new System.EventHandler(this.timer_Motor_Tick);
            // 
            // button_Wander
            // 
            this.button_Wander.Font = new System.Drawing.Font("Biondi", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Wander.Location = new System.Drawing.Point(12, 156);
            this.button_Wander.Name = "button_Wander";
            this.button_Wander.Size = new System.Drawing.Size(259, 45);
            this.button_Wander.TabIndex = 22;
            this.button_Wander.Text = "Wander";
            this.button_Wander.UseVisualStyleBackColor = true;
            this.button_Wander.Click += new System.EventHandler(this.button_Wander_Click);
            // 
            // mainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(702, 478);
            this.Controls.Add(this.button_Wander);
            this.Controls.Add(this.button_Light);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox4);
            this.Name = "mainForm";
            this.Text = "HCR Control Form";
            this.Load += new System.EventHandler(this.mainForm_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_MotorL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_MotorR)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btn_Connect;
        private System.Windows.Forms.ComboBox comboBox_PortRate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_ComPort;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_Motor_Right;
        private System.Windows.Forms.Button btn_Motor_Stop;
        private System.Windows.Forms.Button btn_Motor_Left;
        private System.Windows.Forms.Button btn_Motor_Backward;
        private System.Windows.Forms.Button btn_Motor_Forward;
        private System.Windows.Forms.RichTextBox rTB_Log;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Timer timer_Sensor;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label_IR1;
        private System.Windows.Forms.Label label_BumperL;
        private System.Windows.Forms.Label label_BumperR;
        private System.Windows.Forms.Label label_BumperC;
        private System.Windows.Forms.Label label_IR3;
        private System.Windows.Forms.Label label_IR2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TrackBar trackBar_MotorL;
        private System.Windows.Forms.TrackBar trackBar_MotorR;
        private System.Windows.Forms.CheckBox checkBox_Debug;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.Label label_IR7;
        private System.Windows.Forms.Label label_IR6;
        private System.Windows.Forms.Label label_IR5;
        private System.Windows.Forms.Label label_IR4;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Button button_Light;
        private System.Windows.Forms.Timer timer_Motor;
        private System.Windows.Forms.Button button_Wander;
    }
}

