﻿///HCR sample program
///


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.Win32;

namespace HCRConsole
{
    public partial class mainForm : Form
    {

        private delegate void ConfigurationDelegate();
        private string[] _comportList;
       
        private string _systemlog = "";

        private HCR.Core _hcr ;

        private int[] IR = new int[7];
        private bool[] Bumper = new bool[3];

        private Random rnd;



        public mainForm()
        {
            InitializeComponent();
        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            RegistryKey keyCom = Registry.LocalMachine.OpenSubKey("Hardware\\DeviceMap\\SerialComm");
            if (keyCom != null)
            {
                string[] sSubKeys = keyCom.GetValueNames();

                _comportList = new string[keyCom.ValueCount];

                int i = 0;
                foreach (string sName in sSubKeys)
                {
                    _comportList[i] = (string)keyCom.GetValue(sName);

                    comboBox_ComPort.Items.Add(_comportList[i]);
                    i++;

                }
            }

            if (comboBox_ComPort.Items.Count > 0)
            {
                comboBox_ComPort.SelectedIndex = 0;
            }

            _hcr = new HCR.Core();
          

        }



        public void SetConfiguration()
        {

            // InvokeRequired compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.


            if (this.InvokeRequired)
            {
                ConfigurationDelegate d = new ConfigurationDelegate(SetConfiguration);
                this.Invoke(d, new object[] { });
            }
            else
            {


                if (checkBox_Debug.Checked)
                {
                    rTB_Log.AppendText(_systemlog + "\r");
                }


                label_IR1.Text = IR[0].ToString();
                label_IR2.Text = IR[1].ToString();
                label_IR3.Text = IR[2].ToString();

                label_IR4.Text = IR[3].ToString();
                label_IR5.Text = IR[4].ToString();
                label_IR6.Text = IR[5].ToString();
                label_IR7.Text = IR[6].ToString();


          

                label_BumperL.Text = Bumper[0].ToString();
                label_BumperC.Text = Bumper[1].ToString();
                label_BumperR.Text = Bumper[2].ToString();

                if (Bumper[0] == true)
                {
                    label_BumperL.BackColor = Color.Red;
                }
                else
                {
                    label_BumperL.BackColor = Color.Green;
                }
                if (Bumper[1] == true)
                {
                    label_BumperC.BackColor = Color.Red;
                }

                else
                {
                    label_BumperC.BackColor = Color.Green;
                }
                if (Bumper[2] == true)
                {
                    label_BumperR.BackColor = Color.Red;
                }

                else
                {
                    label_BumperR.BackColor = Color.Green;
                }
            

                _systemlog = "";


            }



        }

        private void btn_Connect_Click(object sender, EventArgs e)
        {
            try
            {

                if (!_hcr.IsConnected)
                {
                    HCR.Core.SerialPortConfig config = new HCR.Core.SerialPortConfig();
                    config.BaudRate = System.Convert.ToInt32(comboBox_PortRate.Text);
                    config.PortName = comboBox_ComPort.Text;
                    _hcr.Connect(config);
                    _hcr.DataReceived += new HCR.Core.DataReceivedEventHandler(_hcr_DataReceived);
                    btn_Connect.Text = "断开连接";

                    timer_Sensor.Enabled = true;


                }
                else
                {
                    btn_Connect.Text = "连接HCR";
                    _hcr.Disconnect();
                  
                    timer_Sensor.Enabled = false;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        void _hcr_DataReceived(object sender, DateTime timestamp)
        {

         
            Bumper = new bool[3] { false, false, false };
            IR = _hcr.IR;
            Bumper = _hcr.Bumper;

            _systemlog = Bumper[0].ToString();

            _systemlog += "|"+Bumper[1].ToString();

            _systemlog += "|" + Bumper[2].ToString();

           
            SetConfiguration();
        }

        private void timer_Sensor_Tick(object sender, EventArgs e)
        {
           // _hcr.ReadBumper();

        }

     

        private void btn_Motor_Stop_Click(object sender, EventArgs e)
        {
            _hcr.SetMotorPower(0, 0);

            SetConfiguration();
        }

        private void btn_Motor_Forward_Click(object sender, EventArgs e)
        {
            _hcr.SetMotorPower(40,40);
          
            SetConfiguration();
        }

        private void btn_Motor_Backward_Click(object sender, EventArgs e)
        {
            _hcr.SetMotorPower(-40, -40);

            SetConfiguration();
        }

        private void btn_Motor_Right_Click(object sender, EventArgs e)
        {
            _hcr.SetMotorPower(30, -30);

            SetConfiguration();
        }

        private void btn_Motor_Left_Click(object sender, EventArgs e)
        {
            _hcr.SetMotorPower(-30, 30);

            SetConfiguration();
        }



        private void trackBar_MotorL_Scroll(object sender, EventArgs e)
        {

            _hcr.SetMotorPower(trackBar_MotorL.Value, trackBar_MotorR.Value);
            SetConfiguration();
        }

        private void trackBar_MotorR_Scroll(object sender, EventArgs e)
        {
            _hcr.SetMotorPower(trackBar_MotorL.Value, trackBar_MotorR.Value);
            SetConfiguration();
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            rTB_Log.Clear();
        }

        private void label_IR1_Click(object sender, EventArgs e)
        {

        }

        private void label_IR2_Click(object sender, EventArgs e)
        {

        }

        private void label_IR3_Click(object sender, EventArgs e)
        {

        }

        private void button_Light_Click(object sender, EventArgs e)
        {
            _hcr.TurnOnLight();
        }

        private void button_Wander_Click(object sender, EventArgs e)
        {
            if (timer_Motor.Enabled)
            {
                timer_Motor.Enabled = false;
                _hcr.SetMotorPower(0, 0);
                button_Wander.Text = "Wander";
            }
            else
            {
                timer_Motor.Enabled = true;
                button_Wander.Text = "Stop Wander";
            }
        }

        private void timer_Motor_Tick(object sender, EventArgs e)
        {
            rnd = new Random();

            int leftmotor = rnd.Next(60);
            int rightmotor = rnd.Next(60);

            _hcr.SetMotorPower(leftmotor, rightmotor);

            SetConfiguration();
        }

      

    
    }
}
